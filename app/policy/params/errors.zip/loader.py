# app/policy/params/loader.py
from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml

from app.policy.params.schema import MoneyPolicy, TimePolicy, PointsTierPolicy, PolicyBundle
from app.policy.params.guardrails import validate_policy


def _deep_get(d: dict, key: str) -> Any:
    if key not in d:
        raise KeyError(f"Missing key: {key}")
    return d[key]


def load_policy_yaml(path: str | None = None) -> PolicyBundle:
    """
    Loads policy bundle from YAML.
    - default: app/policy/params/defaults.yaml
    - override path by env POLICY_YAML_PATH or param
    """
    if path is None:
        path = os.environ.get("POLICY_YAML_PATH")

    if path is None:
        base = Path(__file__).resolve().parent
        path = str(base / "defaults.yaml")

    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Policy YAML not found: {p}")

    raw = yaml.safe_load(p.read_text(encoding="utf-8")) or {}

    money = _deep_get(raw, "money")
    time = _deep_get(raw, "time")
    points = _deep_get(raw, "points_tier")

    bundle = PolicyBundle(
        money=MoneyPolicy(
            platform_fee_rate=float(_deep_get(money, "platform_fee_rate")),
            actuator_commission_rate=float(_deep_get(money, "actuator_commission_rate")),
            pg_fee_rate=float(_deep_get(money, "pg_fee_rate")),
        ),
        time=TimePolicy(
            payment_timeout_minutes=int(_deep_get(time, "payment_timeout_minutes")),
            cooling_days=int(_deep_get(time, "cooling_days")),
            seller_decision_timeout_hours=int(_deep_get(time, "seller_decision_timeout_hours")),
            deal_deadline_hours=int(_deep_get(time, "deal_deadline_hours")),
            offer_deadline_hours=int(_deep_get(time, "offer_deadline_hours")),
        ),
        points_tier=PointsTierPolicy(
            points_earn_rate=float(_deep_get(points, "points_earn_rate")),
            points_expire_days=int(_deep_get(points, "points_expire_days")),
            tier_window_days=int(_deep_get(points, "tier_window_days")),
            tier_min_gmv=int(_deep_get(points, "tier_min_gmv")),
        ),
    )

    validate_policy(bundle)
    return bundle