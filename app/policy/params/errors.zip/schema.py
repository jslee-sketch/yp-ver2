# app/policy/params/schema.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


ShippingMode = Literal["PER_RESERVATION", "PER_QTY"]


@dataclass(frozen=True)
class MoneyPolicy:
    # 플랫폼 수수료(예: 0.05 = 5%)
    platform_fee_rate: float
    # 액추에이터 커미션(예: 정산금의 0.02 = 2%)
    actuator_commission_rate: float
    # 결제 PG 수수료(예: 0.03 = 3%) - 지금은 더미여도 됨
    pg_fee_rate: float


@dataclass(frozen=True)
class TimePolicy:
    # 예약 후 결제 제한 시간(분) - 지금 정책: 10분
    payment_timeout_minutes: int
    # 쿨링(청약철회) 기간(일) - 예: 7일
    cooling_days: int
    # 셀러 의사결정(승인/거절) 마감 시간(시간)
    seller_decision_timeout_hours: int
    # 딜 마감까지 남은 시간(시간) - 프로젝트에 따라 의미 다르면 나중에 분리
    deal_deadline_hours: int
    # 오퍼 마감까지 남은 시간(시간)
    offer_deadline_hours: int


@dataclass(frozen=True)
class PointsTierPolicy:
    # 포인트 적립률(예: 0.01 = 1%)
    points_earn_rate: float
    # 포인트 만료(일)
    points_expire_days: int
    # 티어 계산 기간(일)
    tier_window_days: int
    # 티어 최소 거래금액(원)
    tier_min_gmv: int


@dataclass(frozen=True)
class PolicyBundle:
    money: MoneyPolicy
    time: TimePolicy
    points_tier: PointsTierPolicy